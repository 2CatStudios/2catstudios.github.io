UnityMusicPlayer 1.25
Thank you for using UMP!


UnityMusicPlayer has been developed by
2Cat Studios

	Michael Bethke	- Programming and Application Design
	Jan Heemstra	- Planning and Support
	Joshua Wade	- Additional Planning and Product Testing


Thanks for downloading UnityMusicPlayer!

To install, simply drag the UnityMusicPlayer folder (or just the application) to any desired location.


For help, please refer to the FAQ & Tutorial included in this download.



— 3rd Party License Information —

“Roboto”, licensed under the Creative Commons Attribution 2.5 ( http://creativecommons.org/licenses/by/2.5/legalcode )


“Quicksand”, by Andrew Paglinawan, licensed under the SIL Open Font License (OFL)


Various icons from “Open Iconic” licensed under:

	The MIT License (MIT)

	Copyright (c) 2014 Waybury

	Permission is hereby granted, free of charge, to any person obtaining a copy
	of this software and associated documentation files (the "Software"), to deal
	in the Software without restriction, including without limitation the rights
	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
	copies of the Software, and to permit persons to whom the Software is
	furnished to do so, subject to the following conditions:

	The above copyright notice and this permission notice shall be included in
	all copies or substantial portions of the Software.



If you have any questions or concerns, please email us at gibsonbethke@gmail.com